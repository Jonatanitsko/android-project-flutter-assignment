import 'package:english_words/english_words.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

enum Status { Uninitialized, Authenticated, Authenticating, Unauthenticated }

class AuthRepository with ChangeNotifier {
  FirebaseAuth _auth;
  User? _user;
  Status _status = Status.Uninitialized;
  List<WordPair> _wordpair_list = <WordPair>[];

  List<WordPair> get wordpair_list => _wordpair_list;

  AuthRepository.instance() : _auth = FirebaseAuth.instance {
    _auth.authStateChanges().listen(_onAuthStateChanged);
    _user = _auth.currentUser;
    _onAuthStateChanged(_user);
  }

  Status get status => _status;

  User? get user => _user;

  bool get isAuthenticated => status == Status.Authenticated;

  Future<UserCredential?> signUp(String email, String password) async {
    try {
      _status = Status.Authenticating;
      notifyListeners();
      return await _auth.createUserWithEmailAndPassword(
          email: email, password: password);
    } catch (e) {
      print(e);
      _status = Status.Unauthenticated;
      notifyListeners();
      return null;
    }
  }

  Future<bool> signIn(String email, String password) async {
    try {
      _status = Status.Authenticating;
      notifyListeners();
      await _auth.signInWithEmailAndPassword(email: email, password: password);
      await getFav();
      return true;
    } catch (e) {
      print(e);
      _status = Status.Unauthenticated;
      notifyListeners();
      return false;
    }
  }

  void updateFav() {
    FirebaseFirestore _firestore = FirebaseFirestore.instance;
    List<String> to_up =  _wordpair_list.map((WordPair wordPairItem) => wordPairItem.asPascalCase.toString()).toList();
    _firestore
        .collection("favorites")
        .doc(user!.email)
        .set({"list": to_up});
  }

  Future<bool> getFav() async {
    try {
      FirebaseFirestore _firestore = FirebaseFirestore.instance;
      await _firestore
          .collection("favorites")
          .doc(user!.email)
          .get()
          .then((value) {
        List.from(value.data()!['list']).forEach((element) {
          final beforeNonLeadingCapitalLetter = RegExp(r"(?=(?!^)[A-Z])");
          List<String> splitPascalCase(String input) =>
              input.split(beforeNonLeadingCapitalLetter);
          List<String> split = splitPascalCase(element.toString());
          WordPair pair =
              new WordPair(split[0].toLowerCase(), split[1].toLowerCase());
          _wordpair_list.add(pair);
        });
      });
      notifyListeners();
      return true;
    } catch (e) {
      _status = Status.Unauthenticated;
      notifyListeners();
      return false;
    }
  }

  Future signOut() async {
    updateFav();
    _auth.signOut();
    _status = Status.Unauthenticated;
    _wordpair_list = <WordPair>[];
    notifyListeners();
    return Future.delayed(Duration.zero);
  }

  Future<void> _onAuthStateChanged(User? firebaseUser) async {
    if (firebaseUser == null) {
      _user = null;
      _status = Status.Unauthenticated;
    } else {
      _user = firebaseUser;
      _status = Status.Authenticated;
    }
    notifyListeners();
  }
}
